import tkinter as tk
from ply import lex

# Definir los tokens
tokens = (
    'IDENTIFICADOR',
    'TIPO_DATO',
    'PUNTO',
    'OPERADOR_IGUAL',
    'NUMERO',
    'RESERVADA_WHILE',
    'PUNTO_Y_COMA',
    'FIN_LINEA',
    'LLAVE_DE_APERTURA',
    'LLAVE_DE_CIERRE',
    'PARENTESIS_DE_APERTURA',
    'PARENTESIS_DE_CIERRE',
    'CORCHETE_DE_APERTURA',
    'CORCHETE_DE_CIERRE',
    'OPERADOR_INCREMENTO'
)

# Definir las reglas para los tokens
def t_IDENTIFICADOR(t):
    r'[a-zA-Z_][a-zA-Z0-9_]*'
    if t.value == 'int':
        t.type = 'TIPO_DATO'
    if t.value == 'for':
        t.type = 'RESERVADA_WHILE'
    return t
    
def t_PUNTO(t):
    r'\.'
    return t

def t_OPERADOR_IGUAL(t):
    r'='
    return t

def t_NUMERO(t):
    r'\d+'
    t.value = int(t.value)
    return t


def t_PUNTO_Y_COMA(t):
    r';'
    return t

def t_LLAVE_DE_APERTURA(t):
    r'{'
    return t

def t_LLAVE_DE_CIERRE(t):
    r'}'
    return t

def t_PARENTESIS_DE_APERTURA(t):
    r'\('
    return t

def t_PARENTESIS_DE_CIERRE(t):
    r'\)'
    return t

def t_CORCHETE_DE_APERTURA(t):
    r'\['
    return t

def t_CORCHETE_DE_CIERRE(t):
    r'\]'
    return t

def t_OPERADOR_INCREMENTO(t):
    r'\+\+'
    return t

# Ignorar espacios y tabulaciones
t_ignore = ' \t'

# Contador de líneas
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Manejar errores y contar líneas
def t_error(t):
    print(f"Carácter ilegal '{t.value[0]}' en la línea {t.lexer.lineno}")
    t.lexer.skip(1)

# Crear el analizador léxico
lexer = lex.lex()

# Función para analizar el código
def analizar_codigo():
    codigo = codigo_text.get("1.0", "end -1c")
    lexer.input(codigo)
    resultados = []

    for tok in lexer:
        resultados.append((tok.type, tok.value, tok.lineno))

    # Mostrar resultados en la nueva tabla
    for widget in resultados_frame.winfo_children():
        widget.destroy()

    # Crear una tabla para mostrar los resultados
    tabla = tk.Frame(resultados_frame, bg='white')
    tabla.grid(row=0, column=0)

    tk.Label(tabla, text="TOKEN", bg='white').grid(row=0, column=0, padx=5, pady=5)
    tk.Label(tabla, text="LEXEMA", bg='white').grid(row=0, column=1, padx=5, pady=5)
    tk.Label(tabla, text="LÍNEA", bg='white').grid(row=0, column=2, padx=5, pady=5)

    for i, resultado in enumerate(resultados, start=1):
        tk.Label(tabla, text=resultado[0], bg='white').grid(row=i, column=0, padx=60, pady=0)
        tk.Label(tabla, text=resultado[1], bg='white').grid(row=i, column=1, padx=60, pady=0)
        tk.Label(tabla, text=str(resultado[2]), bg='white').grid(row=i, column=2, padx=60, pady=0)

# Crear la interfaz gráfica
ventana_principal = tk.Tk()
ventana_principal.title("Analizador Léxico")
ventana_principal.configure(bg='grey')  # Cambiar el color de fondo principal

# Panel de entrada de código
panel_codigo = tk.Frame(ventana_principal, bg='grey')  # Cambiar el color de fondo del panel
panel_codigo.grid(row=0, column=0, padx=10, pady=10)

codigo_text = tk.Text(panel_codigo, height=35, width=60, bg='white')  # Cambiar el color de fondo del área de texto
codigo_text.insert(tk.END, "static void burbuja(int arreglo[])\n{\n    for(int i=0; i < arreglo.length = 1; i++)\n}")
codigo_text.grid(row=2, column=2, padx=10, pady=10)

# Botones en la parte superior
boton_actualizar = tk.Button(panel_codigo, text="Analizar", command=analizar_codigo, bg='lightcyan')  # Cambiar el color del botón
boton_actualizar.grid(row=1, column=0, pady=5)

# Panel de resultados
panel_resultados = tk.Frame(ventana_principal, bg='grey')  # Cambiar el color de fondo del panel
panel_resultados.grid(row=0, column=1, padx=10, pady=10)

# Frame para mostrar resultados
resultados_frame = tk.Frame(panel_resultados, bg='white')
resultados_frame.grid(row=0, column=0)

ventana_principal.mainloop()
